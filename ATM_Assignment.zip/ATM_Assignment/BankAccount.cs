﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Assignment
{
    public class BankAccount
    {
        public Person user;
        public string email;
        public string CardNumber;
        public string PinCode;
        public int accountBalance;
       public string info()
        {
            return user.First_Name + "," + user.Last_Name + "," + email + "," + CardNumber + "," + PinCode + "," + accountBalance ;
        }
        public bool CardNumber_correct(string c)
        {
            int n;
            bool isNumber = int.TryParse(c, out n);
            return isNumber && c.Length == 9;
        }
        public bool PinCode_correct(string c)
        {
            int n;
            bool isNumber = int.TryParse(c, out n);
            return isNumber && c.Length ==4;
        }
        public BankAccount(Person user, string mail, string c_n, string p_c, int balance)
        {
            if (CardNumber_correct(c_n) && PinCode_correct(p_c))
            {

                this.user = user;
                email = mail;
                CardNumber = c_n;
                PinCode = p_c;
                accountBalance = balance;
            }
        }
    }
}
