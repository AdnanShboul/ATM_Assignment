﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ATM_Assignment
{
    public class Bank
    {
        public Bank()
        {

        }
        public int bankCapacity;
        public BankAccount[] BankAccounts;
        public int NumberOfCustomers;
        public Bank(int capacity)
        {
            bankCapacity = capacity;
            NumberOfCustomers = 0;
            BankAccounts = new BankAccount[bankCapacity];
        }


        public bool IsBankUser(string c, string p)
        {
            if (NumberOfCustomers == 0)
            {
                return false;
            }
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                if (BankAccounts[i].CardNumber.Equals(c) && BankAccounts[i].PinCode.Equals(p))
                {
                    return true;
                }
            }
            return false;
        }

        public void AddNewAccount(BankAccount t)
        {
            if (NumberOfCustomers < bankCapacity) { BankAccounts[NumberOfCustomers++] = t; }
        }


        public int CheckBalance(string c, string p)
        {
            if (NumberOfCustomers == 0)
            {
                return 0;
            }
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                if (BankAccounts[i].CardNumber.Equals(c) && BankAccounts[i].PinCode.Equals(p))
                {
                    return BankAccounts[i].accountBalance;
                }
            }
            return 0;
        }

        public void Withdraw(BankAccount t, int w)
        {
            if (NumberOfCustomers == 0)
            {
                return ;
            }
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                if (BankAccounts[i].accountBalance>= w && BankAccounts[i].CardNumber.Equals(t.CardNumber) && BankAccounts[i].PinCode.Equals(t.PinCode))
                {
                     BankAccounts[i].accountBalance-= w;
                }
            }
           
        }
        public void Save()
        {
            string[] lines = new string[NumberOfCustomers];

            for (int i = 0; i < NumberOfCustomers; i++)
            {
                lines[i] = BankAccounts[i].info();
            }

                string docPath =
              Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

         
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "BankAccounts.txt")))
            {
                foreach (string line in lines)
                    outputFile.WriteLine(line);
                outputFile.Close();
            }
        }

        public void Load()
        {
            
            string docPath =
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using (StreamReader sr = new StreamReader(Path.Combine(docPath, "BankAccounts.txt")))
            {
                string s = "";
                while ( !sr.EndOfStream){
                    string[] j = sr.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    Person p = new Person();
                    p.First_Name = j[0];
                    p.Last_Name = j[1];
                    BankAccount c = new BankAccount(p, j[2], j[3], j[4], int.Parse(j[5]));
                    this.AddNewAccount(c);

                }
                sr.Close();


            }
        }
        public void Deposit(BankAccount t, int w)
        {
            if (NumberOfCustomers == 0)
            {
                return;
            }
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                if ( BankAccounts[i].CardNumber.Equals(t.CardNumber) && BankAccounts[i].PinCode.Equals(t.PinCode))
                {
                    BankAccounts[i].accountBalance += w;
                }
            }

        }

       
    }
}
