﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Assignment
{
  public  class Person
    {
        public Person()
        {
            First_Name = "First_Name";
            Last_Name = "Last_Name";
        }
        public string First_Name;
        public string Last_Name;

    }
}
